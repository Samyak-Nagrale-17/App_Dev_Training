// Selecting all necessary elements
const regForm = document.querySelector("#multistepForm");
const steps = document.querySelectorAll(".step");
const sidebarStepIcons = document.querySelectorAll(".currStepIcon");
const prevButtons = document.querySelectorAll("#prevButton");
const nextButtons = document.querySelectorAll("#nextButton");
const confirmButton = document.querySelector("#confirmButton");

// object for finalPrice Calculation
let selectedPlanDetails = {
    plan:null,
    planCost: null,
    duration: "monthly", 
    addOns :[]
}

// Current step tracking
// Start at step 0
let currentStep = 0; 

// Convert button NodeLists to arrays for easier handling with events
let prevButtonsArray = Array.from(prevButtons);
let nextButtonsArray = Array.from(nextButtons);

// Set up event listeners for navigation buttons
prevButtonsArray.forEach((prevButton) => {
    prevButton.addEventListener('click', (event) => {
        event.preventDefault();
        moveToPreviousStep();
    });
});

nextButtonsArray.forEach((nextButton) => {
    nextButton.addEventListener('click', (event) => {
        event.preventDefault();
        // for input validation
        if(currentStep == 0 && !validateUserInput()){
            console.log("clicked on next button");
            return;
        } 
        moveToNextStep();
    });
});

// Function to navigate to the previous step
function moveToPreviousStep() {

    // Hide current step
    steps[currentStep].classList.remove('active');
    sidebarStepIcons[currentStep].classList.remove("currStepActive");

    // Decrement step and show the previous step
    currentStep -= 1;
    steps[currentStep].classList.add('active');
    sidebarStepIcons[currentStep].classList.add("currStepActive");

    // Update button visibility based on current step
    updateButtons();
}

// Function to navigate to the next step
function moveToNextStep() {
    // Hide current step
    steps[currentStep].classList.remove('active');
    sidebarStepIcons[currentStep].classList.remove("currStepActive");

    // Increment step and show the next step
    currentStep += 1;
    steps[currentStep].classList.add('active');
    sidebarStepIcons[currentStep].classList.add("currStepActive");

    // Update button visibility based on current step
    updateButtons();
}

// Function to update button visibility based on current step
function updateButtons() {
    // Hide 'Previous' button on first step
    if (currentStep === 0) {
        prevButtonsArray[0].style.display = "hidden";
    } else {
        prevButtonsArray[0].style.display = "inline-block";
    }

    // Show 'Confirm' button only on the last step
    if (currentStep === steps.length - 1) {
        nextButtonsArray[0].style.display = "none";
        confirmButton.style.display = "inline-block";
    } else {
        nextButtonsArray[0].style.display = "inline-block";
        confirmButton.style.display = "none";
    }
}

// Initial setup to hide/show buttons correctly on page load
updateButtons();

function validateUserInput(){
    const username = document.getElementById("username").value.trim()
    const useremail = document.getElementById("useremail").value.trim()
    const userphone = document.getElementById("userphone").value.trim()

    let isValid = true

    // validate the username
    const usernamePattern = /^[a-zA-Z-_]/
    if(!usernamePattern.test(username)){
        document.getElementById("usernameErr").style.display = "block"
        document.getElementById("username").style.border = "1px solid hsl(354, 84%, 57%)"
        isValid = false 
    }
    else{
        document.getElementById("usernameErr").style.display = "none"
    }

    // validate the email
    const useremailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if(!useremailPattern.test(useremail)){
        document.getElementById("useremailErr").style.display = "block"
        document.getElementById("useremail").style.border = "1px solid hsl(354, 84%, 57%)"
        isValid = false
    }
    else{
        document.getElementById("useremailErr").style.display = "none"
    }

    //validate usernumber
    const userphonePattern = /^\d{10}$/
    if(!userphonePattern.test(userphone)){
        document.getElementById("userphoneErr").style.display = "block"
        document.getElementById("userphone").style.border = "1px solid hsl(354, 84%, 57%)"
        isValid = false
    }
    else{
        document.getElementById("userphoneErr").style.display = "none"
    }

    return isValid
}

// page 2 switcher
const switcher = document.querySelector(".switch");
switcher.addEventListener("click", () => {
  const val = switcher.querySelector("input").checked;
  if (val) {
    document.querySelector(".monthly").classList.remove("sw-active");
    document.querySelector(".yearly").classList.add("sw-active");
    selectedPlanDetails.duration = "yearly"
  } else {
    document.querySelector(".monthly").classList.add("sw-active");
    document.querySelector(".yearly").classList.remove("sw-active");
    selectedPlanDetails.duration = "monthly"
  }
  switchPrice(val);
});

function switchPrice(checked){
  addOffersInPlans(checked)
  const yearlyPrice = [90, 120, 150];
  const monthlyPrice = [9, 12, 15];
  const prices = document.querySelectorAll(".priceTag");

  if (checked) {
    prices[0].innerHTML = `$${yearlyPrice[0]}/yr`;
    prices[1].innerHTML = `$${yearlyPrice[1]}/yr`;
    prices[2].innerHTML = `$${yearlyPrice[2]}/yr`;
  } else {
    prices[0].innerHTML = `$${monthlyPrice[0]}/mo`;
    prices[1].innerHTML = `$${monthlyPrice[1]}/mo`;
    prices[2].innerHTML = `$${monthlyPrice[2]}/mo`;
  }

  // do the same for addon prices
  const yearlyPriceAddon = [10,20]
  const monthlyPriceAddon = [1,2]
  const priceAddon = document.querySelectorAll(".priceAddon")
  if (checked){
    priceAddon[0].innerHTML = `$${yearlyPriceAddon[0]}/yr`
    priceAddon[1].innerHTML = `$${yearlyPriceAddon[1]}/yr`
    priceAddon[2].innerHTML = `$${yearlyPriceAddon[1]}/yr`
  }
  else{
    priceAddon[0].innerHTML = `$${monthlyPriceAddon[0]}/mo`
    priceAddon[1].innerHTML = `$${monthlyPriceAddon[1]}/mo`
    priceAddon[2].innerHTML = `$${monthlyPriceAddon[1]}/mo`
  }
}

// select the plans
const plans = document.querySelectorAll(".planCard");
plans.forEach((plan) => {
    plan.addEventListener("click", () => {
    //   document.querySelector(".selected").classList.remove("selected");
    //   plan.classList.add("selected");
        const selectedPlan = document.querySelector(".planCard.selected");
        if (selectedPlan) {
            selectedPlan.classList.remove("selected");
        }
        // Select the clicked plan
        plan.classList.add("selected");
        // get the selected plan
        const currSelectedPlan = plan.querySelector(".planDetails p").textContent
        const currSelectedPlanPrice = plan.querySelector(".planDetails .priceTag").textContent
        selectedPlanDetails.plan = currSelectedPlan  
        selectedPlanDetails.planCost = currSelectedPlanPrice
    })
})


// add the 2 month free offer if toggle is in yearly
function addOffersInPlans(checked){
    const planCardsDetails = document.querySelectorAll(".planDetails")
    if(checked){
        planCardsDetails.forEach((plan)=>{
            plan.querySelector(".offer").style.display = "block"
        })
    }
    else{
        planCardsDetails.forEach((plan)=>{
            plan.querySelector(".offer").style.display = "none"
        })
    }
}

// get the checkboxes inside the boxes
const inputCheckboxes = document.querySelectorAll(".box input")
// add a event listener to all 3 checkbozes to change bg of selected plan
inputCheckboxes.forEach((inputCheckbox) => {
    inputCheckbox.addEventListener('click', function(){
        const currAddOn = inputCheckbox.parentElement
        if(inputCheckbox.checked){
            // const currAddOn = inputCheckbox.parentElement
            currAddOn.classList.toggle("ad-selected")
            // inputCheckbox.parentElement.classList.toggle("ad-selected")

            //add the selected addon to object
            const selectAddon = currAddOn.querySelector(".description label").textContent
            const selectAddonPrice = currAddOn.querySelector(".priceAddon").textContent

            selectedPlanDetails.addOns.push({"description":selectAddon, "price":selectAddonPrice})

        } else{
            // remove the bg on unchecking the input checkbox
            // inputCheckbox.parentElement.classList.toggle("ad-selected")
            currAddOn.classList.toggle("ad-selected")
            // selectedPlanDetails.addOns.push({"description":selectAddon, "price":selectAddonPrice})
            selectedPlanDetails.addOns.pop()
        }
    })
})


calculateTotalPrice()
function calculateTotalPrice(){
    const finalPrice = document.querySelector("p.totalPrice")

    let pricePlan = selectedPlanDetails.planCost.match(/(\d+)/)

    // get the addon price
    let addOnPrices = []
    let addOnAllPrices = selectedPlanDetails.addOns
    
    addOnAllPrices.forEach((addOnAllPrice) => {
        addOnPrices.push(addOnAllPrice.price)   
    })
    console.log(addOnPrices)
}
